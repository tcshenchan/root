#ifndef __audio_h
#define __audio_h
#include <rtthread.h>

#include <stm32f10x_tim.h>
#include <stm32f10x.h>
#include <board.h>

const unsigned char* wav_data[];
#endif
